package com.example.desiner.Service;

import com.example.desiner.ApiException.ApiException;
import com.example.desiner.Model.MyUser;
import com.example.desiner.Repository.MyUserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;


@Service
@RequiredArgsConstructor
public class MyUserService {
private final MyUserRepository myUserRepository;

    public MyUser getUser(Integer id){
        MyUser myUser = myUserRepository.findMyUserById(id);
        if (myUser==null)
            throw new ApiException("user not found");
        return myUser;
    }

public void addUser(MyUser myUser){
      myUserRepository.save(myUser);
}

public void updateUser(MyUser myUser,Integer id) {
    MyUser old = myUserRepository.findMyUserById(id);
    if (old == null) {
        throw new ApiException("there is no user to update");
    }
    old.setId(myUser.getId());
    old.setUsername(myUser.getUsername());
    old.setPassword(myUser.getPassword());
    old.setRole(myUser.getRole());
    myUserRepository.save(old);
}
public void deleteUser(Integer id){
      MyUser user1=myUserRepository.findMyUserById(id);
      if (user1==null){
          throw new ApiException("there is no user to delete");
      }
      myUserRepository.delete(user1);
  }
    public void register(MyUser myUser){
        String hash=new BCryptPasswordEncoder().encode(myUser.getPassword());
        myUser.setRole(hash);
        myUser.setRole("CUSTOMER");
        myUserRepository.save(myUser);
    }

//    public MyUser getCustomerById(Integer id) {
//        MyUser myUser = myUserRepository.findCustomerById(id);
//        if (myUser == null) {
//            throw new ApiException("Not found");
//        }
//        return myUser;
//    }

}
