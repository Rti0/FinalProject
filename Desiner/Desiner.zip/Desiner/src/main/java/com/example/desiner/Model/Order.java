package com.example.desiner.Model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@AllArgsConstructor
@NoArgsConstructor
@Data
@Table(name = "myOrder")
public class Order {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(columnDefinition = "varchar(200)  not null ")
    private String description;

    @Column(columnDefinition = "int not null ")
    private Integer totalPrice;

    @Column(columnDefinition = "int not null ")
    private Integer area;

    @Column(columnDefinition = "varchar(20) not null check( status='notStarted' or status='inProgress' or status='Done' )")
    private String status;

//    private Integer designerId;



    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "designerId")
    @JsonIgnore
    private Designer designer;



    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "customerId")
    @JsonIgnore
    private Customer customer;



    @OneToOne(cascade = CascadeType.ALL,mappedBy = "order")
    @PrimaryKeyJoinColumn
    private RateOrder rateOrder;

}
