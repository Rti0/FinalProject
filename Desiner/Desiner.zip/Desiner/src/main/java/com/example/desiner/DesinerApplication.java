package com.example.desiner;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DesinerApplication {

    public static void main(String[] args) {
        SpringApplication.run(DesinerApplication.class, args);
    }

}
