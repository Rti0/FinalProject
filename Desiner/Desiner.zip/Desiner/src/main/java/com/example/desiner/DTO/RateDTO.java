package com.example.desiner.DTO;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class RateDTO {

    private Integer OrderId;

    private Integer rating;

}
