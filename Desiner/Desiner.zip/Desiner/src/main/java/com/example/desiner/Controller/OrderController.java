package com.example.desiner.Controller;

import com.example.desiner.Model.Customer;
import com.example.desiner.Model.Designer;
import com.example.desiner.Model.Order;
import com.example.desiner.Service.OrderService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("api/v1/order")
@RequiredArgsConstructor
public class OrderController {
    private final OrderService orderService;

    @GetMapping("/get")
    public ResponseEntity getAll() {
        return ResponseEntity.status(200).body(orderService.getAll());
    }


//        @PostMapping("/add")
//    public ResponseEntity addOrder(@Valid @RequestBody Order order) {
//            orderService.addOrder(order);
//            return ResponseEntity.status(200).body("order added");
//        }
    @PostMapping("/addOrder")
    public ResponseEntity addOrder1(@AuthenticationPrincipal Customer customer, @RequestBody Order order,@PathVariable Integer servicesId) {
        orderService.addOrder1(customer.getId(), order, order.getTotalPrice());
        return ResponseEntity.status(200).body("order Add");
    }

    @PutMapping("/update/{orderId}")
    public ResponseEntity updateOrder(@AuthenticationPrincipal Customer customer,@Valid @RequestBody Order order,@PathVariable Integer orderId) {
        orderService.updateOrder(customer.getId(),order,orderId);
        return ResponseEntity.status(200).body("order updated");
    }

    @DeleteMapping("/delete/{orderId}")
    public ResponseEntity deleteOrder(@AuthenticationPrincipal @PathVariable Integer customerId, @PathVariable Integer orderId) {
        orderService.deleteOrder(customerId, orderId);
        return ResponseEntity.status(200).body("order deleted");
    }

    //endpoint

    @PutMapping("change-statues/{orderId}/{status}")
    public ResponseEntity changeStatus(@AuthenticationPrincipal Designer designer, @PathVariable Integer orderId, @PathVariable String status) {
        orderService.changeStatus(designer.getId(), orderId, status);
        return ResponseEntity.status(200).body("Status Changed");
    }

    @GetMapping("/get-status")
    public ResponseEntity getOrderByStatus(@AuthenticationPrincipal String status) {
        Order order = orderService.getOrderByStatus(status);
        return ResponseEntity.status(200).body(order);
    }

    @GetMapping("/get-customers")
    public ResponseEntity findAllCustomer() {
        List<Order> orders = orderService.getAllCustomer();
        return ResponseEntity.status(200).body(orders);
    }
}
