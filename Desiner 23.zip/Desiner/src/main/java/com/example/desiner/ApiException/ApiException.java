package com.example.desiner.ApiException;

public class ApiException extends RuntimeException {
    public ApiException(String message) {
        super(message);
    }
}