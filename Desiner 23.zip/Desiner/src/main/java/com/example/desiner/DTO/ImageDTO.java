package com.example.desiner.DTO;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class ImageDTO {

    private Integer DesignerBusinessId;
    private String url;

}
