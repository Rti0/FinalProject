package com.example.desiner;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DesinerApplicationTests {

    @Test
    void contextLoads() {
    }

}
